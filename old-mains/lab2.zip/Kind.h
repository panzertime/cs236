#ifndef KIND
#define KIND



enum Kind {
		COMMA,
		PERIOD,
		Q_MARK,
		LEFT_PAREN,
		RIGHT_PAREN,
		COLON,
		COLON_DASH,
		SCHEMES,
		FACTS,
		RULES,
		QUERIES,
		ID,
		STRING
	} ;

#endif
