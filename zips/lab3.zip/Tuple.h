#ifndef TUPLE_H
#define TUPLE_H

#include <string>

class Tuple : public vector<string> {
	
public:
	
	// everything I need looks inherited

};

#endif
